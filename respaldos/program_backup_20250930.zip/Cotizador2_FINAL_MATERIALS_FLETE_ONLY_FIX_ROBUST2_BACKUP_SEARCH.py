#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
VC999 Packaging+ Cotizador
Versión: 6.3.29
Cambios vs 6.3.18:
- CM1100: tapa 12" fuerza bomba "300 m3" sin bloquear el combobox.
- Exclusión Gas Flush con corte mecánico en CM780/860/900A/1100 (consolidado).
- TS455: opción "Proceso" presente; TS540 sin "Proceso".
- Panel de opciones se autoajusta a su contenido (menos espacio en blanco).
- Selector de idioma aplicado a más textos estáticos.
- Materials: moneda predeterminada MXN.
- Oculta consola en Windows.
"""

import os, sys, json, uuid, traceback, shutil, subprocess

# === I18N helpers ===
LANG_DEFAULT = "es"  # siempre iniciar en español
_I18N_OPT = {
    # Canonical English -> Spanish
    "Gas Flush": "Inyección de gas",
    "Positive Air Sealer": "Selladora de aire positivo",
    "Bi-active sealing system": "Sistema de sellado bi-activo",
    "Bi active sealing system": "Sistema de sellado bi-activo",
    "With mechanical cut": "Con corte mecánico",
    "with mechanical cut": "con corte mecánico",
    "Without mechanical cut": "Sin corte mecánico",
    "NO mechanical Cut": "Sin corte mecánico",
    "Mechanical Cut": "Corte mecánico",
    "Operation": "Operación",
    "Voltage": "Voltaje",
    "Lid size": "Altura de tapa",
    "Die Configuration": "Configuración de la matriz",
    "Die Shape": "Forma de la matriz",
    "Photo Registration": "Registro de fotografías",
    "Index": "Índice",
    "Tray unload system": "Sistema de descarga de bandeja fácil",
    "Tray Unload System": "Sistema de descarga de bandeja fácil",
    "Automatic lid": "Tapa automática",
    "Manual lid": "Tapa manual",
    "Skin": "Skin",
    "MAP/Lidding": "MAP/Sellado",
    "MAP / Lidding": "MAP/Sellado",
    "None": "Ninguno",
    "Yes": "Sí",
    "No": "No",
}
# Tokens to translate inside composed options
_I18N_TOKENS = sorted(_I18N_OPT.keys(), key=len, reverse=True)

def _opt_to_es(text: str) -> str:
    if not isinstance(text, str): return text
    out = text
    for k in _I18N_TOKENS:
        out = out.replace(k, _I18N_OPT[k])
    return out

# Build reverse map (Spanish -> English canonical)
_I18N_OPT_REV = {v: k for k, v in _I18N_OPT.items()}

def _opt_to_en(text: str) -> str:
    if not isinstance(text, str): return text
    out = text
    for k, v in _I18N_OPT_REV.items():
        out = out.replace(k, v)
    return out
# === End I18N helpers ===
from datetime import datetime
from decimal import Decimal, InvalidOperation

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
# --- Early crash logger ---
import sys as _sys_e, traceback as _tb_e, os as _os_e
def _boot_excepthook(et, ev, tb):
    try: appdir=_os_e.path.dirname(_os_e.path.abspath(_sys_e.argv[0]))
    except: appdir=_os_e.getcwd()
    for name in ("error.log","error.txt"):
        try:
            with open(_os_e.path.join(appdir,name),"a",encoding="utf-8") as f:
                f.write("["+__import__("datetime").datetime.now().strftime("%Y-%m-%d %H:%M:%S")+"] "+repr(ev)+"\n")
                f.write("".join(_tb_e.format_exception(et,ev,tb))+"\n\n")
        except: pass
try: _sys_e.excepthook=_boot_excepthook
except: pass


# Dependencias opcionales
try:
    from docx import Document
except Exception:
    Document = None

try:
    from docx2pdf import convert as docx2pdf_convert
except Exception:
    docx2pdf_convert = None

APP_TITLE = "VC999 Packaging+ Cotizador v6.3.29"

# ----- Utilidades de ruta y configuración -----
def _app_dir() -> str:
    try:
        return os.path.dirname(os.path.abspath(sys.argv[0]))
    except Exception:
        return os.getcwd()

CFG_FILE = "app_config.json"
HIST_PACK = "historial_packaging.json"
HIST_MATS = "historial_materials.json"
BACKUP_DIR = "respaldos"
ADVISORS_FILE = "advisors.json"
DEFAULT_ADVISORS = ["José Manuel Rayotorres Martínez"]

def _read_cfg():
    p = os.path.join(_app_dir(), CFG_FILE)
    if not os.path.exists(p):
        return {}
    try:
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def _write_cfg(cfg: dict):
    try:
        with open(os.path.join(_app_dir(), CFG_FILE), "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

def _load_json_list(path: str, default_list):
    p = os.path.join(_app_dir(), path)
    if not os.path.exists(p):
        return list(default_list)
    try:
        with open(p, "r", encoding="utf-8") as f:
            data = json.load(f)
            if isinstance(data, list):
                return data
    except Exception:
        pass
    return list(default_list)

def _save_json_list(path: str, data_list):
    p = os.path.join(_app_dir(), path)
    try:
        with open(p, "w", encoding="utf-8") as f:
            json.dump(data_list, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

def _load_hist(path: str) -> list:
    p = os.path.join(_app_dir(), path)
    if not os.path.exists(p):
        return []
    try:
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []

def _save_hist(path: str, rows: list) -> None:
    p = os.path.join(_app_dir(), path)
    try:
        with open(p, "w", encoding="utf-8") as f:
            json.dump(rows, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

def _write_error_log(e: Exception):
    try:
        with open(os.path.join(_app_dir(), "error.log"), "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {repr(e)}\n")
            f.write(traceback.format_exc() + "\n\n")
    except Exception:
        pass

# ----- Utilidades numéricas y formato -----
def _fmt_money(val: Decimal, currency: str = "USD") -> str:
    try:
        s = f"{Decimal(val):,.2f}"
    except Exception:
        s = "0.00"
    return f"US${s}" if currency.upper() == "USD" else f"$ {s} {currency.upper()}"

def _parse_decimal_safe(text: str) -> Decimal:
    if text is None:
        return Decimal("0")
    t = str(text).strip()
    if not t:
        return Decimal("0")
    t = t.replace(",", "")
    try:
        return Decimal(t)
    except InvalidOperation:
        try:
            if t.count(".") > 1:
                parts = t.split(".")
                t2 = "".join(parts[:-1]) + "." + parts[-1]
                return Decimal(t2)
        except Exception:
            pass
    return Decimal("0")

def _pct_clean(s: str) -> str:
    try:
        t = (s or "").replace("%","").strip()
        v = float(t)
        v = 0.0 if v < 0 else v
        v = 100.0 if v > 100 else v
        return f"{int(v)}%" if v.is_integer() else f"{v:.2f}%"
    except Exception:
        return "0%"

# ------------------ configuración de máquinas ------------------
MACHINES = {
    "CM360LR.docx": {"base": Decimal("3995"), "options": {
        "Voltage": [("110 V / 1 ph / 50/60 hz ($ 0 USD)", Decimal("0"))],
        "Gas Flush ($ 695 USD)": ("chk", Decimal("695")),
        "Sample parts kit included": [("Yes ($ 0 USD)", Decimal("0"))],
    }},
    "CM430.docx": {"base": Decimal("3695"), "options": {
"Voltage": [("110 V / 1 ph / 50/60 hz ($ 0 USD)", Decimal("0"))],
        "Gas Flush ($ 695 USD)": ("chk", Decimal("695")),
        "Sample parts kit included": [("Yes ($ 0 USD)", Decimal("0"))],
}},
    "CM640.docx": {"base": Decimal("15995"), "options": {
        "Voltage": [("208 V / 3 ph / 60 hz ($ 0 USD)", Decimal("0")),
                    ("220 V/1 PH/60 hz (100m3 pump only) ($ 1,495 USD)", Decimal("1495")),
                    ("400 V / 3 ph / 50 hz ($ 495 USD)", Decimal("495")),
                    ("440 V / 3 ph / 60 hz ($ 495 USD)", Decimal("495")),
                    ("480 V / 3 ph / 60 hz ($ 495 USD)", Decimal("495"))],
        "Gas Flush ($ 995 USD)": ("chk", Decimal("995")),
        "Positive Air Sealer (for use in low vacuum and gas flush applications) ($ 695 USD)": ("chk", Decimal("695")),
    }},
    "CM780.docx": {"base": Decimal("20995"), "options": {
        "Voltage": [("208 V / 3 ph / 60 hz ($ 0 USD)", Decimal("0")),
                    ("400 V / 3 ph / 50 hz ($ 495 USD)", Decimal("495")),
                    ("480 V / 3 ph / 60 hz ($ 495 USD)", Decimal("495"))],
        "Lid size": [('8\" Lid Height ($ 0 USD)', Decimal("0")), ('10\" Lid Height ($ 995 USD)', Decimal("995"))],
        "Mechanical Cut w/ Positive Air Sealer": [("None ($ 0 USD)", Decimal("0")), ("Yes ($ 3,495 USD)", Decimal("3495"))],
        "Pump Options": [("1x 200m3 pump (4.2 kw = 5.71 hp) ($ 0 USD)", Decimal("0"))],
        "Gas Flush ($ 995 USD)": ("chk", Decimal("995")),
        "Positive Air Sealer (for use in low vacuum and gas flush applications) ($ 695 USD)": ("chk", Decimal("695")),
        "Bi-active Sealing System ($ 1,295 USD)": ("chk", Decimal("1295")),
        "Sample parts kit included": [("Yes ($ 0 USD)", Decimal("0"))],
    }},
    "CM860.docx": {"base": Decimal("24995"), "options": {
        "Voltage": [("208 V / 3 ph / 60 hz / 40A ($ 0 USD)", Decimal("0")), ("400 V / 3 ph / 50 hz ($ 495 USD)", Decimal("495")), ("480 V / 3 ph / 60 hz ($ 495 USD)", Decimal("495"))],
        "Lid size": [('8\" Lid Height ($ 0 USD)', Decimal("0")), ('10\" Lid Height ($ 995 USD)', Decimal("995")), ('12\" Lid Height ($ 1,995 USD)', Decimal("1995"))],
        "Operation": [("Automatic lid with NO mechanical cut ($ 0 USD)", Decimal("0")), ("Automatic lid, WITH mechanical cut (distance between seal bars: 655mm) ($ 3,495 USD)", Decimal("3495"))],
        "Pump Options": [("1x 300m3 pump (6.6kw=8.97HP) ($ 0 USD)", Decimal("0"))],
        "Bi-active Sealing System ($ 1,995 USD)": ("chk", Decimal("1995")),
        "Gas Flush ($ 995 USD)": ("chk", Decimal("995")),
        "Positive Air Sealer ($ 695 USD)": ("chk", Decimal("695")),
        "Sample parts kit included": [("Yes ($ 0 USD)", Decimal("0"))],
    }},
    "CM900A.docx": {"base": Decimal("32995"), "options": {
        "Voltage": [("208 V / 3 ph / 60 hz / 40A ($ 0 USD)", Decimal("0")), ("400 V / 3 ph / 50 hz ($ 495 USD)", Decimal("495")), ("480 V / 3 ph / 60 hz ($ 495 USD)", Decimal("495"))],
        "Lid size": [('8" Lid Height ($ 0 USD)', Decimal("0")),
                     ('10" Lid Height ($ 1,000 USD)', Decimal("1000")),
                     ('12" Lid Height ($ 2,000 USD)', Decimal("2000"))],
        "Operation": [("Automatic lid with NO mechanical cut ($ 0 USD)", Decimal("0")), ("Automatic lid, WITH mechanical cut (distance between seal bars: 815mm) ($ 4,995 USD)", Decimal("4995"))],
        "Pump Options": [("300 m3 (6.6kw=8.97HP) ($ 0 USD)", Decimal("0"))],
        "Bi-active Sealing System ($ 1,995 USD)": ("chk", Decimal("1995")),
        "Gas Flush ($ 995 USD)": ("chk", Decimal("995")),
        "Positive Air Sealer ($ 695 USD)": ("chk", Decimal("695")),
    }},
    "CM1100.docx": {"base": Decimal("34995"), "options": {
        "Voltage": [("208 V / 3 ph / 60 hz / 40A ($ 0 USD)", Decimal("0")), ("400 V / 3 ph / 50 hz ($ 495 USD)", Decimal("495")), ("480 V / 3 ph / 60 hz ($ 495 USD)", Decimal("495"))],
        "Lid size": [('10\" Lid Height ($ 0 USD)', Decimal("0")), ('12\" Lid Height ($ 1,000 USD)', Decimal("1000"))],
        "Operation": [("Automatic lid with NO mechanical cut ($ 0 USD)", Decimal("0")), ("Automatic lid, WITH mechanical cut (distance between seal bars: 815mm) ($ 4,995 USD)", Decimal("4995"))],
        "Pump Options": [("300 m3 (6.6kw=8.97HP) ($ 0 USD)",
                         Decimal("0")),
                         ("2 x 200 m3 (pumps internally mounted, 6.6kw=8.97HP each) ($ 13,995 USD)", Decimal("13995")),
                         ("2 x 300 m3 (pumps internally mounted, 6.6kw=8.97HP each) ($ 13,995 USD)", Decimal("13995"))],
        "Bi-active Sealing System ($ 1,995 USD)": ("chk", Decimal("1995")),
        "Gas Flush ($ 995 USD)": ("chk", Decimal("995")),
        "Positive Air Sealer ($ 695 USD)": ("chk", Decimal("695")),
    }},
    "TS420.docx": {"base": Decimal("23995"), "options": {
        "Voltaje": [("220V / 3ph / 60hz ($ 0 USD)", Decimal("0")), ("400 V / 3 ph / 50 hz ($ 149 USD)", Decimal("149")), ("480 V / 3 ph / 60 hz ($ 149 USD)", Decimal("149"))],
        "Registro de fotografías": [("Yes ($ 0 USD)", Decimal("0"))],
        "Configuración de matriz": [("1 UP ($ 3,995 USD)", Decimal("3995")), ("2 UP ($ 4,595 USD)", Decimal("4595")),
                                    ("3 UP ($ 5,195 USD)", Decimal("5195")), ("4 UP ($ 5,795 USD)", Decimal("5795")),
                                    ("5 UP ($ 6,395 USD)", Decimal("6395")), ("6 UP ($ 6,995 USD)", Decimal("6995"))],
        "La forma de la matriz (Geometría)": [("Other", Decimal("0")), ("Rectangle", Decimal("0")), ("Round", Decimal("0")),
                                              ("Square", Decimal("0")), ("Rectangle Standard VC No.3 tray", Decimal("0"))],
    }},
"TS455.docx": {"base": Decimal("28995"), "options": {        "Voltaje": [("220V / 3ph / 60hz ($ 0 USD)", Decimal("0")), ("400 V / 3 ph / 50 hz ($ 149 USD)", Decimal("149")), ("480 V / 3 ph / 60 hz ($ 149 USD)", Decimal("149"))],
        "Registro de fotografías": [("Yes ($ 0 USD)", Decimal("0"))],
        "Proceso": [("MAP/Lidding", Decimal("0")), ("Skin", Decimal("0"))],        "Configuración de matriz": [("1 UP ($ 6,995 USD)", Decimal("6995")), ("2 UP ($ 7,595 USD)", Decimal("7595")), ("3 UP ($ 8,195 USD)", Decimal("8195")), ("4 UP ($ 8,795 USD)", Decimal("8795")), ("5 UP ($ 6,395 USD)", Decimal("6395")), ("6 UP ($ 6,995 USD)", Decimal("6995"))],
        "La forma de la matriz (Geometría)": [("Other", Decimal("0")), ("Rectangle", Decimal("0")), ("Round", Decimal("0")), ("Square", Decimal("0")), ("Rectangle Standard VC No.3 tray", Decimal("0"))],        
    }},
    "TS540.docx": {"base": Decimal("31995"), "options": {
        "Indice": [("340 mm ($ 0 USD)", Decimal("0"))],        "Voltaje": [("220V / 3ph / 60hz ($ 0 USD)", Decimal("0")), ("400 V / 3 ph / 50 hz ($ 149 USD)", Decimal("149")), ("480 V / 3 ph / 60 hz ($ 149 USD)", Decimal("149"))],
        "Registro de fotografías": [("Sí ($ 0 USD)", Decimal("0"))],
        "Sistema de descarga de bandeja fácil ($ 2,226 USD)": ("chk", Decimal("2226")),
        "Forma de la matriz": [("Rectángulo", Decimal("0")), ("Redondo", Decimal("0")), ("Cuadrado", Decimal("0")), ("Rectángulo estándar VC No.3 bandeja", Decimal("0"))],
        "Configuración de la matriz": [("1 UP ($ 6,995 USD)", Decimal("6995")), ("2 UP ($ 7,595 USD)", Decimal("7595")), ("3 UP ($ 8,195 USD)", Decimal("8195")), ("4 UP ($ 8,795 USD)", Decimal("8795"))],
    }},
}

DEFAULT_CONCEPTS = [("Con orden de compra", "35"), ("Contra aviso de entrega", "55"), ("Al instalar", "10")]

# Traducciones de UI (clave ES -> {es,en})
TRANSLATIONS = {
    "Eliminar": {"es": "Eliminar", "en": "Delete"},
    "Cancelar": {"es": "Cancelar", "en": "Cancel"},
    "Abrir PDF": {"es": "Abrir PDF", "en": "Open PDF"},
    "Abrir DOCX": {"es": "Abrir DOCX", "en": "Open DOCX"},
    "Abrir archivo": {"es": "Abrir archivo", "en": "Open file"},
    "Notas": {"es": "Notas", "en": "Notes"},
    "Monto": {"es": "Monto", "en": "Amount"},
    "Flete": {"es": "Flete", "en": "Freight"},
    "Moneda": {"es": "Moneda", "en": "Currency"},
    "Eliminar último": {"es": "Eliminar último", "en": "Remove last"},
    "Agregar ítem": {"es": "Agregar ítem", "en": "Add item"},
    "Unitario": {"es": "Unitario", "en": "Unit price"},
    "Cantidad": {"es": "Cantidad", "en": "Quantity"},
    "Descripción": {"es": "Descripción", "en": "Description"},
    "Ítems": {"es": "Ítems", "en": "Items"},
    "Datos de la cotización": {"es": "Datos de la cotización", "en": "Quotation data"},
    "Opciones de máquina": {"es": "Opciones de máquina", "en": "Machine options"},
    "Contrato comercial": {"es": "Contrato comercial", "en": "Commercial contract"},
    "Limpiar": {"es": "Limpiar", "en": "Clear"},
    "Generar Word/PDF": {"es": "Generar Word/PDF", "en": "Generate Word/PDF"},
    "Encabezado": {"es": "Encabezado", "en": "Header"},
    "Nuevo ítem": {"es": "Nuevo ítem", "en": "New item"},
    "Opciones": {"es": "Opciones", "en": "Options"},
    "Flete y notas": {"es": "Flete y notas", "en": "Freight and notes"},
    "Subtotal:": {"es": "Subtotal:", "en": "Subtotal:"},
    "IVA:": {"es": "IVA:", "en": "VAT:"},
    "Total:": {"es": "Total:", "en": "Total:"},
    "Packaging+": {"es": "Packaging+", "en": "Packaging+"},
    "Materials": {"es": "Materials", "en": "Materials"},
    "Historial": {"es": "Historial", "en": "History"},
    "Cliente:": {"es": "Cliente:", "en": "Client:"},
    "Fecha:": {"es": "Fecha:", "en": "Date:"},
    "Asesor:": {"es": "Asesor:", "en": "Advisor:"},
    "Validez:": {"es": "Validez:", "en": "Validity:"},
    "Plantilla (.docx):": {"es": "Plantilla (.docx):", "en": "Template (.docx):"},
    "Precio base (USD):": {"es": "Precio base (USD):", "en": "Base price (USD):"},
    "Disponibilidad:": {"es": "Disponibilidad:", "en": "Availability:"},
    "Concepto (%)": {"es": "Concepto (%)", "en": "Concept (%)"},
    "Fecha de vencimiento": {"es": "Fecha de vencimiento", "en": "Due label"},
    "Agregar": {"es": "Agregar", "en": "Add"},
    "Buscar:": {"es": "Buscar:", "en": "Search:"},
    "Filtrar": {"es": "Filtrar", "en": "Filter"},
    "Abrir...": {"es": "Abrir...", "en": "Open..."},
    "Exportar JSON": {"es": "Exportar JSON", "en": "Export JSON"},
}

# ------------------ utilidades DOCX ------------------
def _replace_in_paragraph(paragraph, key: str, value: str):
    if key not in paragraph.text:
        return
    runs = paragraph.runs
    full = "".join(r.text for r in runs)
    new = full.replace(key, value)
    if not runs:
        paragraph.add_run(new); return
    runs[0].text = new
    for r in runs[1:]:
        r.text = ""

def _replace_in_table(table, key: str, value: str):
    for row in table.rows:
        for cell in row.cells:
            for p in cell.paragraphs:
                _replace_in_paragraph(p, key, value)

def docx_replace_placeholders(doc: "Document", mapping: dict):
    for p in doc.paragraphs:
        for k, v in mapping.items():
            _replace_in_paragraph(p, k, v)
    for table in doc.tables:
        for k, v in mapping.items():
            _replace_in_table(table, k, v)

# ------------------ UI principal ------------------
class App(tk.Tk):
    def _mat_generate(self):
        """Genera DOCX y PDF en Materials desde plantilla elegida."""
        try:
            from docx import Document

            # Helper: reemplaza SOLO {{flete_texto}} / {{flete texto}} en cualquier parte del DOCX
            def _force_replace_flete(docx_path, value):
                import zipfile, os, tempfile, shutil, re
                tmpdir = tempfile.mkdtemp()
                try:
                    with zipfile.ZipFile(docx_path, 'r') as zin:
                        zin.extractall(tmpdir)
                    pat = re.compile(
                        r'\{(?:\s|<[^>]+>)*\{' +
                        r'(?:\s|<[^>]+>)*f(?:\s|<[^>]+>)*l(?:\s|<[^>]+>)*e(?:\s|<[^>]+>)*t(?:\s|<[^>]+>)*e' +
                        r'(?:\s|<[^>]+>|_|-)+' +
                        r'(?:\s|<[^>]+>)*t(?:\s|<[^>]+>)*e(?:\s|<[^>]+>)*x(?:\s|<[^>]+>)*t(?:\s|<[^>]+>)*o' +
                        r'(?:\s|<[^>]+>)*\}(?:\s|<[^>]+>)*\}',
                        re.I
                    )
                    for root, _dirs, files in os.walk(tmpdir):
                        for fn in files:
                            if not fn.lower().endswith(".xml"):
                                continue
                            fpath = os.path.join(root, fn)
                            try:
                                xml = open(fpath, "r", encoding="utf-8").read()
                            except Exception:
                                continue
                            xml2, n = pat.subn(value, xml)
                            if n:
                                with open(fpath, "w", encoding="utf-8") as f:
                                    f.write(xml2)
                    with zipfile.ZipFile(docx_path, 'w', zipfile.ZIP_DEFLATED) as zout:
                        for root, _dirs, files in os.walk(tmpdir):
                            for fn in files:
                                ap = os.path.join(root, fn)
                                arc = os.path.relpath(ap, tmpdir)
                                zout.write(ap, arc)
                finally:
                    try: shutil.rmtree(tmpdir)
                    except Exception: pass

            # Helper: reemplazo XML para placeholders dentro de textboxes/runs partidos
            def _replace_xml_placeholders(docx_path, mapping):
                import zipfile, os, tempfile, shutil, re
                tmpdir = tempfile.mkdtemp()
                try:
                    with zipfile.ZipFile(docx_path, 'r') as zin:
                        zin.extractall(tmpdir)
                    for root, _dirs, files in os.walk(tmpdir):
                        for fn in files:
                            if not fn.lower().endswith(".xml"):
                                continue
                            fpath = os.path.join(root, fn)
                            try:
                                xml = open(fpath, "r", encoding="utf-8").read()
                            except Exception:
                                continue
                            changed = False
                            # exact pass
                            for k, v in mapping.items():
                                if k and k in xml:
                                    xml = xml.replace(k, v); changed = True
                            # fuzzy pass allowing tags/spaces between braces and letters
                            def _rx(ph):
                                name = ph.strip("{}")
                                parts = []
                                for ch in name:
                                    parts.append(re.escape(ch) + r'(?:\s|<[^>]+>)*')
                                inner = r'(?:\s|<[^>]+>)*'.join(parts)
                                pat = r'\{(?:\s|<[^>]+>)*\{' + inner + r'\}(?:\s|<[^>]+>)*\}'
                                return re.compile(pat, re.I)
                            for k, v in mapping.items():
                                try:
                                    rx = _rx(k)
                                    xml, n = rx.subn(v, xml)
                                    if n: changed = True
                                except Exception:
                                    pass
                            if changed:
                                with open(fpath, "w", encoding="utf-8") as f:
                                    f.write(xml)
                    with zipfile.ZipFile(docx_path, 'w', zipfile.ZIP_DEFLATED) as zout:
                        for root, _dirs, files in os.walk(tmpdir):
                            for fn in files:
                                ap = os.path.join(root, fn)
                                arc = os.path.relpath(ap, tmpdir)
                                zout.write(ap, arc)
                finally:
                    try: shutil.rmtree(tmpdir)
                    except Exception: pass
        except Exception as e:
            try:
                messagebox.showerror(APP_TITLE, f"Falta python-docx:\n{e}")
            except Exception:
                pass
            return
        try:
            import os
            from datetime import datetime
            from decimal import Decimal

            
            def _replace_placeholders_doc(doc, rep: dict):
                # Replace in paragraphs robustly (across runs)
                for p in doc.paragraphs:
                    txt = p.text
                    changed = False
                    for k, v in rep.items():
                        if k in txt:
                            txt = txt.replace(k, v); changed = True
                    if changed:
                        for r in p.runs:
                            r.text = ""
                        if p.runs:
                            p.runs[0].text = txt
                        else:
                            p.add_run(txt)
                # Replace in tables cells as whole text
                for t in doc.tables:
                    for row in t.rows:
                        for cell in row.cells:
                            ctext = cell.text
                            changed = False
                            for k, v in rep.items():
                                if k in ctext:
                                    ctext = ctext.replace(k, v); changed = True
                            if changed:
                                cell.text = ctext

            def _fill_template_items_table(doc, items, moneda, subtotal, iva_pct, iva, grand):
                from docx.shared import Cm, RGBColor
                from docx.enum.text import WD_ALIGN_PARAGRAPH
                from docx.oxml import OxmlElement
                from docx.oxml.ns import qn

                def _shade(cell, hex_fill):
                    tcPr = cell._tc.get_or_add_tcPr()
                    shd = OxmlElement('w:shd')
                    shd.set(qn('w:val'), 'clear')
                    shd.set(qn('w:color'), 'auto')
                    shd.set(qn('w:fill'), hex_fill.replace('#',''))
                    tcPr.append(shd)

                def _set_col_widths(tbl, cms):
                    tbl.autofit = False
                    for row in tbl.rows:
                        for i,w in enumerate(cms):
                            try:
                                row.cells[i].width = Cm(w)
                            except Exception:
                                pass

                # Find the table with header containing Qty, Product, Each, Price
                target = None
                for t in doc.tables:
                    if len(t.rows) == 0:
                        continue
                    hdr = t.rows[0].cells
                    head_txt = " | ".join([c.text.strip() for c in hdr])
                    if (("Qty" in head_txt or "Cantidad" in head_txt) and ("Product" in head_txt or "Descripción" in head_txt)
                        and ("Each" in head_txt or "Unitario" in head_txt)):
                        target = t
                        break
                if target is None:
                    # Crear nueva tabla con el formato solicitado
                    target = doc.add_table(rows=1, cols=4)
                    # Estilo con bordes
                    try:
                        target.style = 'Table Grid'
                    except Exception:
                        try:
                            target.style = 'TableGrid'
                        except Exception:
                            pass
                    # Encabezados
                    hdr = target.rows[0].cells
                    hdr[0].text = "Qty"; hdr[1].text = "Product"; hdr[2].text = "Each (MXN)"; hdr[3].text = "Price (MXN)"
                    # Color de encabezado rojo y texto blanco centrado
                    for c in hdr:
                        _shade(c, "#E31C24")
                        for p in c.paragraphs:
                            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                            for r in p.runs:
                                r.font.bold = True
                                r.font.color.rgb = RGBColor(255,255,255)
                    # Anchos 10% | 50% | 20% | 20% aprox en cm para páginas A4/Letter
                    _set_col_widths(target, [2.0, 10.0, 4.0, 4.0])

                # Quitar filas de datos y totales si existían
                while len(target.rows) > 1:
                    r = target.rows[-1]
                    target._tbl._element.remove(r._tr)

                # Asegurar encabezado con formato si venía de plantilla
                hdr = target.rows[0].cells
                try:
                    from docx.shared import RGBColor
                    from docx.enum.text import WD_ALIGN_PARAGRAPH
                    for c in hdr:
                        for p in c.paragraphs:
                            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                            for r in p.runs:
                                r.font.bold = True
                                try:
                                    r.font.color.rgb = RGBColor(255,255,255)
                                except Exception:
                                    pass
                except Exception:
                    pass
                _set_col_widths(target, [2.0, 10.0, 4.0, 4.0])

                # Agregar items
                for desc, qty, each, total in items:
                    r = target.add_row().cells
                    r[0].text = str(qty)
                    r[1].text = desc
                    r[2].text = _fmt_money(each, moneda)
                    r[3].text = _fmt_money(total, moneda)

                # Totales
                labcol = 2  # tercera columna
                # Subtotal
                r = target.add_row().cells
                r[0].text = ""
                r[1].text = ""
                r[2].text = "Product Subtotal"
                r[3].text = _fmt_money(subtotal, moneda)
                # IVA
                r = target.add_row().cells
                r[0].text = ""
                r[1].text = ""
                r[2].text = f"IVA {iva_pct}%"
                r[3].text = _fmt_money(iva, moneda)
                # Total
                r = target.add_row().cells
                r[0].text = ""
                r[1].text = ""
                r[2].text = "Total"
                r[3].text = _fmt_money(grand, moneda)
                # Sombreado suave en totales y alinear a la derecha
                for row in target.rows[-3:]:
                    try:
                        _shade(row.cells[2], "#FFF2CC")
                        _shade(row.cells[3], "#FFF2CC")
                        from docx.enum.text import WD_ALIGN_PARAGRAPH
                        row.cells[2].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.RIGHT
                        row.cells[3].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.RIGHT
                    except Exception:
                        pass
                return True
# 1) Plantilla
            tpl = None
            if hasattr(self, "var_m_tpl"):
                tpl = (self.var_m_tpl.get() or "").strip()
            if not tpl:
                tpl = os.path.join(_app_dir(), "Cotizacion Materials.docx")
            if not os.path.exists(tpl):
                messagebox.showerror(APP_TITLE, "No se encontró la plantilla seleccionada.\nVerifica 'Cotizacion Materials.docx' o el selector de plantilla.")
                return

            # 2) Datos encabezado
            cliente = (self.var_m_cliente.get() or "").strip() or "Cliente"
            fecha = (self.var_m_fecha.get() or "").strip()
            asesor = (self.var_m_asesor.get() or "").strip() or "José Manuel Rayotorres Martínez"
            validez = (self.var_m_validez.get() or "").strip()
            notas = (self.txt_m_notas.get("1.0","end").strip() if hasattr(self,"txt_m_notas") else "")  # usuario decide
            if not notas:
                notas = ""  # dejar espacio en blanco

            
            modo = self.var_m_flete_modo.get() if hasattr(self,"var_m_flete_modo") else "No aplica"
            try:
                monto = _parse_decimal_safe(self.var_m_flete_monto.get()) if hasattr(self,"var_m_flete_monto") else Decimal("0")
            except Exception:
                monto = Decimal("0")
            moneda = self.var_moneda.get() if hasattr(self,"var_moneda") else "MXN"
            if modo == "Incluido":
                flete_texto = "Flete: Incluido" if monto <= 0 else f"Flete: Incluido {_fmt_money(monto, moneda)}"
            elif modo == "No incluido":
                flete_texto = "Flete: No incluido"
            elif modo == "No aplica":
                flete_texto = ""
            else:
                flete_texto = str(modo)
# 3) Ítems
            items = []
            for row, v_desc, v_qty, v_each in getattr(self,"item_rows", []):
                desc = (v_desc.get() or "").strip()
                qty = int(_parse_decimal_safe(v_qty.get() or "0"))
                each = _parse_decimal_safe(v_each.get() or "0")
                if not desc or qty <= 0:
                    continue
                items.append((desc, qty, each, qty*each))

            # 4) Documento
            doc = Document(tpl)
            rep = {
                "{{nombre del cliente}}": cliente,
                "{{cliente}}": cliente,
                "{{fecha}}": fecha,
                "{{asesor}}": asesor,
                "{{validez}}": validez,
                "{{notas}}": notas,
                "{{flete_texto}}": flete_texto,
            }
            if items:
                _i_desc, _i_qty, _i_each, _i_total = items[0]
                rep.update({
                    "{{qty1}}": str(_i_qty),
                    "{{product1}}": _i_desc,
                    "{{each1}}": _fmt_money(_i_each, moneda),
                    "{{price1}}": _fmt_money(_i_total, moneda),
                })
            for p in doc.paragraphs:
                for k,v in rep.items():
                    if k in p.text:
                        for r in p.runs:
                            r.text = r.text.replace(k, v)
            for t in doc.tables:
                for row in t.rows:
                    for cell in row.cells:
                        for k,v in rep.items():
                            if k in cell.text:
                                cell.text = cell.text.replace(k, v)

            
            # 5) Tabla + totales (usar la tabla existente de la plantilla)
            subtotal = Decimal("0")
            iva_pct = int(_parse_decimal_safe(self.var_iva.get())) if hasattr(self,"var_iva") else 16
            # Calcular totales
            for _d, _q, _e, _t in items:
                subtotal += Decimal(str(_t))
            iva = (subtotal * Decimal(iva_pct) / Decimal("100")).quantize(Decimal("0.01"))
            grand = (subtotal + iva).quantize(Decimal("0.01"))

            # Insertar filas en la tabla que contiene {{qty1}} y {{product1}}
            target = None; row_idx = None
            for t in doc.tables:
                for i, row in enumerate(t.rows):
                    row_txt = " | ".join(c.text for c in row.cells)
                    if "{{qty1}}" in row_txt and "{{product1}}" in row_txt:
                        target = t; row_idx = i; break
                if target is not None: break

            
            # Si no se encontró por placeholders, buscar por la fila que ya contiene el primer ítem
            if target is None and items:
                _d0, _q0, _e0, _t0 = items[0]
                _q0s = str(_q0)
                for t in doc.tables:
                    for i, row in enumerate(t.rows):
                        row_txt = " | ".join(c.text for c in row.cells)
                        if _q0s in row_txt and _d0 in row_txt:
                            target = t; row_idx = i; break
                    if target is not None: break
            if target is not None and items:
                # Primera fila
                _d, _q, _e, _t = items[0]
                cells = target.rows[row_idx].cells
                cells[0].text = str(_q)
                cells[1].text = _d
                cells[2].text = _fmt_money(_e, moneda)
                cells[3].text = _fmt_money(_t, moneda)

                # clonar base e insertar filas extra debajo
                from copy import deepcopy
                from docx.table import _Row
                prev_tr = target.rows[row_idx]._tr
                for _d, _q, _e, _t in items[1:]:
                    clone_tr = deepcopy(prev_tr)
                    prev_tr.addnext(clone_tr)
                    new_row = _Row(clone_tr, target)
                    new_row.cells[0].text = str(_q)
                    new_row.cells[1].text = _d
                    new_row.cells[2].text = _fmt_money(_e, moneda)
                    new_row.cells[3].text = _fmt_money(_t, moneda)
                    prev_tr = clone_tr

            # Actualizar placeholders de totales en todo el documento
            rep.update({
                "{{subtotal}}": _fmt_money(subtotal, moneda),
                "{{iva}}": _fmt_money(iva, moneda),
                "{{total}}": _fmt_money(grand, moneda),
            })
            for p in doc.paragraphs:
                for k,v in rep.items():
                    if k in p.text:
                        for r in p.runs:
                            r.text = r.text.replace(k, v)
            for t in doc.tables:
                for row in t.rows:
                    for cell in row.cells:
                        for k,v in rep.items():
                            if k in cell.text:
                                cell.text = cell.text.replace(k, v)
# 6) Guardar DOCX
            out_name = f"{cliente} {fecha}.docx".replace("/", "-")
            init_dir = os.path.dirname(tpl) if tpl else _app_dir()
            out_docx = filedialog.asksaveasfilename(defaultextension=".docx",
                                                    filetypes=[("Word","*.docx")],
                                                    initialdir=init_dir, initialfile=out_name,
                                                    title="Guardar cotización")
            if not out_docx:
                messagebox.showinfo(APP_TITLE, "Operación cancelada.")
                return
            os.makedirs(os.path.dirname(out_docx) or ".", exist_ok=True)
            doc.save(out_docx)
            _force_replace_flete(out_docx, flete_texto)
            _replace_xml_placeholders(out_docx, {"{{notas}}": notas, "{{flete_texto}}": flete_texto, "{{subtotal}}": _fmt_money(subtotal, moneda), "{{iva}}": _fmt_money(iva, moneda), "{{total}}": _fmt_money(grand, moneda)})


            # 7) PDF
            out_pdf = out_docx.replace(".docx",".pdf")
            try:
                if docx2pdf_convert:
                    try:
                        docx2pdf_convert(out_docx, out_pdf)
                    except Exception:
                        _ = self._convert_docx_to_pdf(out_docx, out_pdf)
                else:
                    _ = self._convert_docx_to_pdf(out_docx, out_pdf)
            except Exception as e:
                _write_error_log(e)

            
            # 7.2) Respaldos automáticos de DOCX y PDF
            try:
                import os, shutil
                from datetime import datetime
                backup_dir = os.path.join(_app_dir(), "respaldos")
                os.makedirs(backup_dir, exist_ok=True)
                ts = datetime.now().strftime("%Y%m%d_%H%M%S")
                # DOCX
                try:
                    base_doc = os.path.splitext(os.path.basename(out_docx))[0]
                    b_docx = os.path.join(backup_dir, f"{base_doc}__{ts}.docx")
                    shutil.copy2(out_docx, b_docx)
                except Exception as _e:
                    _write_error_log(_e)
                # PDF si existe
                try:
                    if os.path.exists(out_pdf):
                        base_pdf = os.path.splitext(os.path.basename(out_pdf))[0]
                        b_pdf = os.path.join(backup_dir, f"{base_pdf}__{ts}.pdf")
                        shutil.copy2(out_pdf, b_pdf)
                except Exception as _e:
                    _write_error_log(_e)
            except Exception as _e:
                _write_error_log(_e)
# 8) Historial
            try:
                hist = _load_hist(HIST_MATS)
                hist.append({
                    "fecha": datetime.now().strftime("%Y-%m-%d %H:%M"),
                    "cliente": cliente,
                    "plantilla": os.path.basename(tpl),
                    "monto": f"{_fmt_money(grand, moneda)}",
                    "docx": out_docx,
                    "pdf": out_pdf if os.path.exists(out_pdf) else ""
                })
                _save_hist(HIST_MATS, hist)
            except Exception as e:
                _write_error_log(e)

            # 9) Mensaje final
            msg_pdf = out_pdf if os.path.exists(out_pdf) else "(PDF no disponible)"
            messagebox.showinfo(APP_TITLE, "Documento generado:\n" + out_docx + "\n" + msg_pdf)

        except Exception as e:
            _write_error_log(e)
            messagebox.showerror(APP_TITLE, f"Ocurrió un error al generar:\n{e}")

    # --- Historial: UI y utilidades ---
    def _hist_build_common(self, parent, is_pack: bool):
        import tkinter as tk
        from tkinter import ttk, messagebox
        self._hist_is_pack = getattr(self, "_hist_is_pack", {})
        self._hist_is_pack[parent] = is_pack
        top = ttk.Frame(parent); top.pack(fill="both", expand=True, padx=8, pady=8)
        # Barra de búsqueda
        self._hist_search = getattr(self, "_hist_search", {})
        self._hist_is_pack = getattr(self, "_hist_is_pack", {})
        self._hist_is_pack[parent] = is_pack
        import tkinter as tk
        search_bar = ttk.Frame(top); search_bar.pack(fill="x", pady=(0,6))
        ttk.Label(search_bar, text="Buscar:").pack(side="left")
        qvar = tk.StringVar(value="")
        self._hist_search[parent] = qvar
        ent = ttk.Entry(search_bar, textvariable=qvar, width=40)
        ent.pack(side="left", padx=6)
        ttk.Button(search_bar, text="Filtrar", command=lambda tv=None,par=parent: self._hist_refresh(tv_ref, par)).pack(side="left")
        ttk.Button(search_bar, text="Limpiar", command=lambda: (qvar.set(""), self._hist_refresh(tv_ref, parent))).pack(side="left", padx=6)
        cols = ("fecha","cliente","plantilla","monto","docx","pdf")
        tv = ttk.Treeview(top, columns=cols, show="headings", height=12)
        tv_ref = tv
        for c in cols:
            tv.heading(c, text=c.upper())
        tv.column("fecha", width=140, anchor="w")
        tv.column("cliente", width=180, anchor="w")
        tv.column("plantilla", width=160, anchor="w")
        tv.column("monto", width=110, anchor="e")
        tv.column("docx", width=260, anchor="w")
        tv.column("pdf", width=260, anchor="w")
        tv.pack(fill="both", expand=True, side="top")
        # Doble clic o Enter abre PDF si existe, si no DOCX
        tv.bind("<Double-1>", lambda e, tv=tv: self._hist_open_default(tv))
        tv.bind("<Return>", lambda e, tv=tv: self._hist_open_default(tv))
        btns = ttk.Frame(top); btns.pack(fill="x", pady=6)
        ttk.Button(btns, text="Refrescar", command=lambda tv=tv,par=parent: self._hist_refresh(tv, par)).pack(side="left")
        ttk.Button(btns, text="Abrir DOCX", command=lambda tv=tv: self._hist_open_selected(tv, which="docx")).pack(side="left", padx=6)
        ttk.Button(btns, text="Abrir PDF", command=lambda tv=tv: self._hist_open_selected(tv, which="pdf")).pack(side="left")
        ttk.Button(btns, text="Eliminar", command=lambda tv=tv,par=parent: self._hist_delete_selected(tv, par)).pack(side="right")
        self._hist_refresh(tv, parent)

    def _hist_refresh(self, tree, parent):
        # Permite refrescar con o sin tree (cuando se llama desde botones de búsqueda)
        trees = [tree] if tree else []
        # Buscar un Treeview dentro del parent si no se pasó
        if not trees:
            try:
                for child in parent.winfo_children():
                    for sub in child.winfo_children():
                        if isinstance(sub, ttk.Treeview):
                            trees.append(sub)
            except Exception:
                pass
        for tv in trees:
            for i in tv.get_children():
                tv.delete(i)
        is_pack = self._hist_is_pack.get(parent, True)
        try:
            import os, json
            path = "historial_packaging.json" if is_pack else "historial_materials.json"
            appdir = os.path.dirname(os.path.abspath(__file__))
            fpath = os.path.join(appdir, path)
            rows = []
            if os.path.exists(fpath):
                with open(fpath, "r", encoding="utf-8") as f:
                    rows = json.load(f) or []
            # Filtro por búsqueda
            q = ""
            try:
                qvar = getattr(self, "_hist_search", {}).get(parent)
                q = (qvar.get() if qvar else "").strip().lower()
            except Exception:
                q = ""
            if q:
                def match_row(r):
                    for k in ("fecha","cliente","plantilla","monto","docx","pdf"):
                        if q in str(r.get(k,"")).lower():
                            return True
                    return False
                rows = [r for r in rows if match_row(r)]
            # Poblar
            for r in rows:
                for tv in trees:
                    tv.insert("", "end", values=(
                        r.get("fecha",""),
                        r.get("cliente",""),
                        r.get("plantilla",""),
                        r.get("monto",""),
                        r.get("docx",""),
                        r.get("pdf",""),
                    ))
        except Exception:
            try:
                from tkinter import messagebox
                messagebox.showerror(APP_TITLE, "Error al leer historial.")
            except Exception:
                pass

    
    def _hist_open_selected(self, tree, which="docx"):
        import os, glob
        from tkinter import messagebox
        sel = tree.selection()
        if not sel:
            return
        vals = tree.item(sel[0], "values")
        idx = 4 if which=="docx" else 5
        path = (vals[idx] or "").strip() if len(vals) > idx else ""
        if path and os.path.exists(path):
            self._open_path(path); return
        # Fallback a respaldos con el nombre base
        base = os.path.splitext(os.path.basename(path or (vals[4] if len(vals)>4 else "") or (vals[5] if len(vals)>5 else "")))[0]
        base = base.split("__")[0] if "__" in base else base
        bdir = os.path.join(_app_dir(), "respaldos")
        cand = ""
        if os.path.isdir(bdir) and base:
            pats = [os.path.join(bdir, base + "__*.pdf"), os.path.join(bdir, base + "__*.docx")]
            allc = []
            for pat in pats:
                allc.extend(glob.glob(pat))
            if allc:
                allc.sort(key=lambda x: os.path.getmtime(x), reverse=True)
                cand = allc[0]
        if cand:
            self._open_path(cand)
        else:
            messagebox.showwarning(APP_TITLE, f"No hay ruta de {which.upper()} y no se halló respaldo.")

    
    def _hist_delete_selected(self, tree, parent):
        sel = tree.selection()
        if not sel:
            return
        vals = tree.item(sel[0], "values")
        sel_row = {
            "fecha": vals[0] if len(vals) > 0 else "",
            "cliente": vals[1] if len(vals) > 1 else "",
            "plantilla": vals[2] if len(vals) > 2 else "",
            "monto": vals[3] if len(vals) > 3 else "",
            "docx": vals[4] if len(vals) > 4 else "",
            "pdf": vals[5] if len(vals) > 5 else "",
        }
        is_pack = self._hist_is_pack.get(parent, True)
        path = "historial_packaging.json" if is_pack else "historial_materials.json"
        try:
            import os, json
            appdir = os.path.dirname(os.path.abspath(__file__))
            fpath = os.path.join(appdir, path)
            rows = []
            if os.path.exists(fpath):
                with open(fpath, "r", encoding="utf-8") as f:
                    rows = json.load(f) or []
            idx_to_remove = -1
            for i, r in enumerate(rows):
                if (r.get("fecha","")==sel_row["fecha"] and
                    r.get("cliente","")==sel_row["cliente"] and
                    r.get("plantilla","")==sel_row["plantilla"] and
                    r.get("monto","")==sel_row["monto"] and
                    r.get("docx","")==sel_row["docx"] and
                    r.get("pdf","")==sel_row["pdf"]):
                    idx_to_remove = i
                    break
            if idx_to_remove >= 0:
                rows.pop(idx_to_remove)
                with open(fpath, "w", encoding="utf-8") as f:
                    json.dump(rows, f, ensure_ascii=False, indent=2)
            
            # Limpiar respaldos relacionados a esta cotización
            try:
                import glob, os
                base_pdf = os.path.splitext(os.path.basename(sel_row.get("pdf") or ""))[0]
                base_doc = os.path.splitext(os.path.basename(sel_row.get("docx") or ""))[0]
                base = base_pdf or base_doc
                base = base.split("__")[0] if "__" in base else base
                bdir = os.path.join(_app_dir(), "respaldos")
                if base and os.path.isdir(bdir):
                    for pat in (os.path.join(bdir, base + "__*.pdf"), os.path.join(bdir, base + "__*.docx")):
                        for fp in glob.glob(pat):
                            try: os.remove(fp)
                            except Exception: pass
            except Exception:
                pass
            self._hist_refresh(tree, parent)
        except Exception:
            from tkinter import messagebox
            messagebox.showerror(APP_TITLE, "No se pudo eliminar del historial.")

    def _open_path(self, path: str):
        import os, subprocess, sys
        try:
            if os.name == "nt":
                os.startfile(path)  # type: ignore[attr-defined]
            elif sys.platform == "darwin":
                subprocess.run(["open", path], check=False)
            else:
                subprocess.run(["xdg-open", path], check=False)
        except Exception:
            pass

    def _build_hist(self, parent):
        nb = ttk.Notebook(parent); nb.pack(fill="both", expand=True)
        tab_p = ttk.Frame(nb); tab_m = ttk.Frame(nb)
        nb.add(tab_p, text="Packaging+"); nb.add(tab_m, text="Materials")
        self._hist_build_common(tab_p, is_pack=True)
        self._hist_build_common(tab_m, is_pack=False)

    def __init__(self):
        # i18n init
        try:
            self._i18n_init()
        except Exception:
            pass
        super().__init__()
        self.title(APP_TITLE)
        self.minsize(980, 620)

        # Ocultar consola en Windows
        if os.name == "nt":
            try:
                import ctypes
                hwnd = ctypes.windll.kernel32.GetConsoleWindow()
                if hwnd:
                    ctypes.windll.user32.ShowWindow(hwnd, 0)
            except Exception:
                pass

        self.cfg = _read_cfg()
        self._logo_img = None
        self._trans_widgets = {}

        nb = ttk.Notebook(self); nb.pack(fill="both", expand=True)
        self.tab_pack = ttk.Frame(nb)
        self.tab_mat = ttk.Frame(nb)
        self.tab_hist = ttk.Frame(nb)
        nb.add(self.tab_pack, text="Packaging+")
        nb.add(self.tab_mat, text="Materials")
        nb.add(self.tab_hist, text="Historial")

        self._build_packaging(self.tab_pack)
        self._build_materials(self.tab_mat)
        self._build_hist(self.tab_hist)

        # Aplicar traducción inicial
        self.after(100, self._center_once)
        self.after(150, self._on_language_change)

    def _center_once(self):
        try:
            self.update_idletasks()
            sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
            w, h = min(1120, int(sw*0.8)), min(720, int(sh*0.82))
            x, y = (sw-w)//2, (sh-h)//2
            self.geometry(f"{w}x{h}+{x}+{y}")
        except Exception:
            pass

    # ===== Packaging+ =====
    def _build_packaging(self, parent):
        # Encabezado
        header = ttk.Frame(parent); header.pack(fill="x", padx=8, pady=(8,0))
        self.logo_label = ttk.Label(header, text="")
        self.logo_label.pack(side="left", padx=(0,12))
        self._auto_logo()

        self.lang_var = tk.StringVar(value=self.cfg.get("lang", "Español"))
        lang_cb = ttk.Combobox(header, textvariable=self.lang_var, values=["Español", "English"], state="readonly", width=12)
        lang_cb.pack(side="right")
        lang_cb.bind("<<ComboboxSelected>>", lambda e: self._on_language_change())

        top = ttk.LabelFrame(parent, text="Datos de la cotización"); top.pack(fill="x", padx=8, pady=6)
        self._trans_widgets["Datos de la cotización"] = top

        lbl_plant = ttk.Label(top, text="Plantilla (.docx):"); lbl_plant.grid(row=0, column=0, sticky="w", padx=4, pady=3)
        self._trans_widgets["Plantilla (.docx):"] = lbl_plant
        self.var_plant = tk.StringVar()
        plant_vals = list(MACHINES.keys())
        cb = ttk.Combobox(top, textvariable=self.var_plant, values=plant_vals, state="readonly", width=32)
        cb.grid(row=0, column=1, sticky="w", padx=4, pady=3)
        cb.bind("<<ComboboxSelected>>", lambda e: self._on_template_change())

        lbl_fecha = ttk.Label(top, text="Fecha:"); lbl_fecha.grid(row=0, column=2, sticky="e", padx=4, pady=3)
        self._trans_widgets["Fecha:"] = lbl_fecha
        self.var_fecha = tk.StringVar(value=datetime.now().strftime("%d/%m/%Y"))
        ttk.Entry(top, textvariable=self.var_fecha, width=12).grid(row=0, column=3, sticky="w", padx=4, pady=3)

        lbl_cli = ttk.Label(top, text="Cliente:"); lbl_cli.grid(row=1, column=0, sticky="w", padx=4, pady=3)
        self._trans_widgets["Cliente:"] = lbl_cli
        self.var_cliente = tk.StringVar(); ttk.Entry(top, textvariable=self.var_cliente, width=34).grid(row=1, column=1, sticky="w", padx=4, pady=3)

        lbl_ase = ttk.Label(top, text="Asesor:"); lbl_ase.grid(row=1, column=2, sticky="e", padx=4, pady=3)
        self._trans_widgets["Asesor:"] = lbl_ase
        self.advisors = _load_json_list(ADVISORS_FILE, DEFAULT_ADVISORS)
        self.var_asesor = tk.StringVar(value=(self.advisors[0] if self.advisors else ""))
        self.cb_asesor = ttk.Combobox(top, textvariable=self.var_asesor, values=self.advisors, width=26)
        self.cb_asesor.grid(row=1, column=3, sticky="w", padx=4, pady=3)
        ttk.Button(top, text="Agregar", command=self._add_advisor).grid(row=1, column=4, sticky="w", padx=6)
        self._trans_widgets["Agregar"] = self.cb_asesor.master.grid_slaves(row=1, column=4)[0]

        lbl_base = ttk.Label(top, text="Precio base (USD):"); lbl_base.grid(row=2, column=0, sticky="w", padx=4, pady=3)
        self._trans_widgets["Precio base (USD):"] = lbl_base
        self.var_base = tk.StringVar(value="0")
        ebase = ttk.Entry(top, textvariable=self.var_base, width=12)
        ebase.grid(row=2, column=1, sticky="w", padx=4, pady=3)
        ebase.bind("<FocusOut>", lambda e: (self._normalize_money(self.var_base), self._recalc_pack()))

        lbl_disp = ttk.Label(top, text="Disponibilidad:"); lbl_disp.grid(row=2, column=2, sticky="e", padx=4, pady=3)
        self._trans_widgets["Disponibilidad:"] = lbl_disp
        self.var_disp = tk.StringVar(value="En stock")
        ttk.Combobox(top, textvariable=self.var_disp, values=["En stock", "De 8 a 6 semanas"], width=18).grid(row=2, column=3, sticky="w", padx=4, pady=3)

        lbl_val = ttk.Label(top, text="Validez:"); lbl_val.grid(row=2, column=4, sticky="e", padx=4, pady=3)
        self._trans_widgets["Validez:"] = lbl_val
        self.var_validez = tk.StringVar(value="30 días")
        ttk.Entry(top, textvariable=self.var_validez, width=12).grid(row=2, column=5, sticky="w", padx=4, pady=3)

        # Cuerpo a dos columnas
        mid = ttk.Frame(parent); mid.pack(fill="both", expand=True, padx=8, pady=4)
        mid.columnconfigure(0, weight=2)
        mid.columnconfigure(1, weight=1)

        lf = ttk.LabelFrame(mid, text="Opciones de máquina")
        self._trans_widgets["Opciones de máquina"] = lf
        lf.grid(row=0, column=0, sticky="nsew", padx=(0,6), pady=2)
        self.op_frame = ttk.Frame(lf)
        self.op_frame.pack(fill="both", expand=False)

        rf = ttk.LabelFrame(mid, text="Contrato comercial")
        self._trans_widgets["Contrato comercial"] = rf
        rf.grid(row=0, column=1, sticky="nsew", padx=(6,0), pady=2)
        lbl_conc = ttk.Label(rf, text="Concepto (%)"); lbl_conc.grid(row=0, column=0, padx=6, pady=4, sticky="w")
        self._trans_widgets["Concepto (%)"] = lbl_conc
        lbl_due = ttk.Label(rf, text="Fecha de vencimiento"); lbl_due.grid(row=0, column=1, padx=6, pady=4, sticky="w")
        self._trans_widgets["Fecha de vencimiento"] = lbl_due
        self.var_conc_pct = [tk.StringVar(value="35"), tk.StringVar(value="55"), tk.StringVar(value="10")]
        presets = [x[0] for x in DEFAULT_CONCEPTS]
        self.var_conc_venc = [tk.StringVar(value=presets[0]), tk.StringVar(value=presets[1]), tk.StringVar(value=presets[2])]
        for i in range(3):
            ttk.Entry(rf, textvariable=self.var_conc_pct[i], width=8).grid(row=i+1, column=0, padx=6, pady=3, sticky="w")
            ttk.Combobox(rf, textvariable=self.var_conc_venc[i], values=presets, width=28).grid(row=i+1, column=1, padx=6, pady=3, sticky="we")
        rf.columnconfigure(1, weight=1)

        bottom = ttk.Frame(parent); bottom.pack(fill="x", padx=8, pady=(6,8))
        self.var_total = tk.StringVar(value="US$0.00")
        ttk.Label(bottom, textvariable=self.var_total, font=("Segoe UI", 11, "bold")).pack(side="left")
        btn_clear = ttk.Button(bottom, text="Limpiar", command=self._pack_clear); btn_clear.pack(side="right", padx=(6,0))
        btn_gen = ttk.Button(bottom, text="Generar Word/PDF", command=self._pack_generate); btn_gen.pack(side="right")
        self._trans_widgets["Limpiar"] = btn_clear
        self._trans_widgets["Generar Word/PDF"] = btn_gen

        if plant_vals:
            self.var_plant.set(plant_vals[0]); self._on_template_change()

    def _auto_logo(self):
        path = None
        try:
            p = self.cfg.get("logo_path")
            if p and os.path.exists(p):
                path = p
            else:
                cand = os.path.join(_app_dir(), "vc999_logo.png")
                if os.path.exists(cand):
                    path = cand
                    self.cfg["logo_path"] = cand
                    _write_cfg(self.cfg)
        except Exception:
            path = None
        if not path:
            return
        try:
            img = tk.PhotoImage(file=path)
            try: img = img.subsample(2,2)
            except Exception: pass
            self._logo_img = img
            self.logo_label.configure(image=img)
        except Exception as e:
            messagebox.showwarning(APP_TITLE, f"No se pudo mostrar el logo ({e}).")

    def _add_advisor(self):
        name = (self.var_asesor.get() or "").strip()
        if not name:
            messagebox.showwarning(APP_TITLE, "Escribe el nombre del asesor y presiona 'Agregar asesor'."); return
        if name not in self.advisors:
            self.advisors.append(name)
            _save_json_list(ADVISORS_FILE, self.advisors)
            self.cb_asesor["values"] = self.advisors
            messagebox.showinfo(APP_TITLE, f"Asesor agregado: {name}")

    def _on_template_change(self):
        for w in self.op_frame.winfo_children(): w.destroy()
        plant = self.var_plant.get(); conf = MACHINES.get(plant, {"base": Decimal("0"), "options": {}})
        self.var_base.set(str(conf.get("base", Decimal("0"))))
        self.opt_vars = {}
        self.opt_widgets = {}
        self.opt_grid_info = {}
        r = 0
        for name, data in conf.get("options", {}).items():
            if isinstance(data, tuple) and data[0] == "chk":
                var = tk.BooleanVar(value=False); self.opt_vars[name] = ("chk", var, data[1])
                chk = tk.Checkbutton(self.op_frame, text=self._tr_opt(name), variable=var, anchor="w", wraplength=520, justify="left", command=lambda n=name: (self._recalc_pack(), self._recompute_option_canvas_height()))
                chk.grid(row=r, column=0, columnspan=2, sticky="w", padx=6, pady=1)
                self.opt_widgets[name] = chk; self.opt_grid_info[name] = chk.grid_info().copy()
                r += 1
            else:
                ttk.Label(self.op_frame, text=self._tr_opt(name) + ":").grid(row=r, column=0, sticky="w", padx=6, pady=1)
                var = tk.StringVar()
                vals = [label for (label, price) in data]
                cb = ttk.Combobox(self.op_frame, textvariable=var, values=[self._tr_opt(x) for x in vals], state="readonly", width=58)
                cb.grid(row=r, column=1, sticky="we", padx=6, pady=1)
                var.set(self._tr_opt(vals[0]) if vals else "")
                cb.bind("<<ComboboxSelected>>", lambda e: (self._recalc_pack(), self._recompute_option_canvas_height()))
                self.op_frame.grid_columnconfigure(1, weight=1)
                self.opt_vars[name] = ("combo", var, data)
                self.opt_widgets[name] = cb; self.opt_grid_info[name] = cb.grid_info().copy()
                r += 1

        self._recalc_pack()
        try:
            self._setup_dynamic_behaviors(plant)
        finally:
            self._recompute_option_canvas_height()


    def _tr_opt(self, text: str) -> str:
        lang = self.lang_var.get() if hasattr(self, 'lang_var') else "Español"
        if not text: return text
        # Map common option labels and values
        map_es = {
            "Voltage": "Voltaje",
            "Lid size": "Altura de tapa",
            "Operation": "Operación",
            "Pump Options": "Opciones de bomba",
            "Gas Flush": "Descarga de gas",
            "Positive Air Sealer": "Sellador de aire positivo",
            "Bi-active Sealing System": "Sistema de sellado biactivo",
            "Mechanical Cut w/ Positive Air Sealer": "Corte mecánico con sellador de aire positivo",
            "Index": "Índice",
            "Registro de fotografías": "Registro de fotografías",
            "Proceso": "Proceso",
            "Configuración de matriz": "Configuración de matriz",
            "La forma de la matriz (Geometría)": "La forma de la matriz (Geometría)",
            "Yes": "Sí",
            "No": "No",
            "None": "Ninguno",
            "Automatic lid with NO mechanical cut": "Tapa automática SIN corte mecánico",
            "Automatic lid, WITH mechanical cut": "Tapa automática CON corte mecánico",
        }
        if lang.startswith("English"):
            # If UI in English, ensure English terms
            # Replace Spanish leading keywords
            map_en = {v:k for k,v in map_es.items()}
            for k,v in map_en.items():
                if k in text: text = text.replace(k, v)
            return text
        else:
            # Spanish mode: replace keywords
            for k,v in map_es.items():
                if k in text:
                    text = text.replace(k, v)
            return text

    def _normalize_money(self, var: tk.StringVar):
        try:
            v = _parse_decimal_safe(var.get())
            var.set(f"{v:,.2f}")
        except Exception:
            var.set("0")

    def _recalc_pack(self):
        base = _parse_decimal_safe(self.var_base.get()); total = base
        for name, info in self.opt_vars.items():
            if info[0] == "chk":
                var, price = info[1], info[2]
                if var.get(): total += price
            else:
                var, data = info[1], info[2]; sel = var.get()
                for label, price in data:
                    if label == sel or self._tr_opt(label) == sel: total += price; break
        self.var_total.set(f"US${total:,.2f}")

    def _recompute_option_canvas_height(self):
        try:
            self.update_idletasks()
            # No scrollbars. Let frame size to content and rely on main window layout.
        except Exception:
            pass

    def _pack_clear(self):
        self.var_cliente.set("")
        self.var_fecha.set(datetime.now().strftime("%d/%m/%Y"))
        self.var_asesor.set(self.advisors[0] if self.advisors else "")
        self.var_disp.set("En stock")
        self.var_validez.set("30 días")
        plant = self.var_plant.get(); conf = MACHINES.get(plant, {"base": Decimal("0")})
        self.var_base.set(str(conf.get("base", Decimal("0"))))
        for name, info in getattr(self, "opt_vars", {}).items():
            if info[0] == "chk":
                info[1].set(False)
            else:
                var, data = info[1], info[2]
                vals = [label for (label, price) in data]
                var.set(self._tr_opt(vals[0]) if vals else "")
        for i, v in enumerate(DEFAULT_CONCEPTS):
            self.var_conc_pct[i].set(v[1]); self.var_conc_venc[i].set(v[0])
        self._recalc_pack(); self._recompute_option_canvas_height()

    # --- Idioma ---
    def _on_language_change(self):
        lang = self.lang_var.get() if hasattr(self, 'lang_var') else "Español"
        try:
            self.cfg["lang"] = lang; _write_cfg(self.cfg)
        except Exception:
            pass
        for key, widget in self._trans_widgets.items():
            mapping = TRANSLATIONS.get(key)
            if not mapping:
                continue
            text = mapping.get('es') if lang.startswith('Español') else mapping.get('en')
            try:
                widget.configure(text=text)
            except Exception:
                pass
        # Reconstruir opciones para aplicar traducción en listas
        try:
            self._on_template_change()
        except Exception:
            pass
        # Títulos de pestañas
        try:
            nb = self.children.get('!notebook')
            if nb:
                texts = ["Packaging+", "Materials", "Historial"]
                for i, t in enumerate(texts):
                    m = TRANSLATIONS.get(t, None)
                    if m:
                        nb.tab(i, text=(m['es'] if lang.startswith('Español') else m['en']))
        except Exception:
            pass

    # ------------------------- comportamientos dinámicos -------------------------
    def _setup_dynamic_behaviors(self, plant: str):
        if not hasattr(self, "opt_vars"):
            return

        def show_widget(key: str):
            w = self.opt_widgets.get(key); info = self.opt_grid_info.get(key)
            if w and info:
                try:
                    w.grid(**{k: v for k, v in info.items() if k in ("row","column","columnspan","sticky","padx","pady")})
                except Exception:
                    pass

        def hide_widget(key: str):
            w = self.opt_widgets.get(key)
            if w:
                try: w.grid_remove()
                except Exception: pass

        def configure_mechanical_cut(operation_key: str, gas_key: str, positive_air_key: str = None):
            op_info = self.opt_vars.get(operation_key)
            gas_info = self.opt_vars.get(gas_key)
            pa_info = self.opt_vars.get(positive_air_key) if positive_air_key else None
            if not op_info or not gas_info:
                return
            # operation combo
            op_var = op_info[1]
            op_data = op_info[2] if len(op_info) > 2 else []
            gas_var = gas_info[1]
            pa_var = pa_info[1] if pa_info else None

            def is_mech_cut(sel: str) -> bool:
                s = (sel or "").strip().lower()
                # direct text checks in both languages
                if ("with mechanical cut" in s) or s.startswith("yes") or s.startswith("sí") or ("con corte mec" in s):
                    return True
                if ("no mechanical cut" in s) or s.startswith("none") or s.startswith("ninguno") or ("sin corte mec" in s):
                    return False
                # map back to canonical labels from data
                for lab,_ in op_data:
                    lab_l = lab.lower()
                    if sel == lab or sel == getattr(self, "_tr_opt", lambda x:x)(lab):
                        if "with mechanical cut" in lab_l or lab_l.startswith("yes"):
                            return True
                        if "no mechanical cut" in lab_l or lab_l.startswith("none"):
                            return False
                # fallback: if option key mentions mechanical cut and selection not None
                if "mechanical cut" in operation_key.lower():
                    return "none" not in s and "ninguno" not in s
                return False

            def on_op_change(*_):
                val = op_var.get()
                if is_mech_cut(val):
                    try: gas_var.set(False)
                    except Exception: pass
                    # hide gas widget
                    try:
                        w = self.opt_widgets.get(gas_key)
                        if w: w.grid_remove()
                    except Exception: pass
                    if pa_var:
                        try: pa_var.set(True)
                        except Exception: pass
                else:
                    # show gas again
                    try:
                        w = self.opt_widgets.get(gas_key); info = self.opt_grid_info.get(gas_key)
                        if w and info:
                            w.grid(**{k:v for k,v in info.items() if k in ("row","column","columnspan","sticky","padx","pady")})
                    except Exception: pass
                self._recalc_pack(); self._recompute_option_canvas_height()

            try: op_var.trace_add("write", on_op_change)
            except Exception: pass
            on_op_change()

        def configure_pump_on_lid(lid_key: str, pump_key: str, required_value_substr: str):
            lid_info = self.opt_vars.get(lid_key)
            pump_info = self.opt_vars.get(pump_key)
            if not lid_info or not pump_info:
                return
            lid_var = lid_info[1]
            pump_var = pump_info[1]
            pump_data = pump_info[2]

            default_val = pump_data[0][0] if pump_data else ""
            req_val = default_val
            for lbl, _ in pump_data:
                if "2 x 200 m3" in lbl.lower():
                    req_val = lbl; break

            def on_lid_change(*_):
                val = (lid_var.get() or "").lower()
                if "12" in val:
                    pump_var.set(req_val)
                else:
                    pump_var.set(default_val)
                self._recalc_pack()

            try:
                lid_var.trace_add("write", on_lid_change)
            except Exception:
                pass
            on_lid_change()

        if plant == "CM780.docx":
            configure_mechanical_cut("Mechanical Cut w/ Positive Air Sealer", "Gas Flush ($ 995 USD)")
        elif plant == "CM430.docx":
            configure_mechanical_cut("Operation", "Gas Flush ($ 995 USD)")
        elif plant == "CM860.docx":
            configure_mechanical_cut("Operation", "Gas Flush ($ 995 USD)")
            configure_mechanical_cut("Operation", "Gas Flush ($ 995 USD)")
        elif plant == "CM900A.docx":
            configure_mechanical_cut("Operation", "Gas Flush ($ 995 USD)")
            configure_mechanical_cut("Operation", "Gas Flush ($ 995 USD)")
        elif plant == "CM1100.docx":
            configure_mechanical_cut("Operation", "Gas Flush ($ 995 USD)")
            configure_pump_on_lid("Lid size", "Pump Options", "2 x 200 m3")
    # === I18N in App ===
    def _i18n_init(self):
        # estado de idioma
        try:
            self.lang = getattr(self, "lang", None) or LANG_DEFAULT
        except Exception:
            self.lang = LANG_DEFAULT
        self._prev_lang = self.lang
        # si existe una variable de UI para idioma, sincronizar
        try:
            if hasattr(self, "var_lang") and self.var_lang.get():
                self.lang = "en" if self.var_lang.get().lower().startswith("en") else "es"
        except Exception:
            pass
        self.after(500, self._i18n_watch)

    def _i18n_watch(self):
        # Observa cambios en self.var_lang sin reiniciar
        try:
            v = None
            if hasattr(self, "var_lang"):
                v = self.var_lang.get().lower().strip()
            if v in ("es", "español", "espanol"):
                new_lang = "es"
            elif v in ("en", "english"):
                new_lang = "en"
            else:
                new_lang = self.lang
            if new_lang != self.lang:
                self.lang = new_lang
                self._apply_language()
        except Exception:
            pass
        try:
            self.after(500, self._i18n_watch)
        except Exception:
            pass

    def _apply_language(self):
        # Actualiza valores visibles de combos ya seleccionados
        try:
            for name, info in getattr(self, "opt_vars", {}).items():
                if info[0] == "cmb":
                    var, data = info[1], info[2]
                    cur = var.get()
                    # normaliza a inglés canonical y re-traduce a display target
                    can = _opt_to_en(cur)
                    disp = _opt_to_es(can) if self.lang == "es" else can
                    if disp != cur:
                        var.set(disp)
        except Exception:
            pass

    def _tr_opt(self, text: str) -> str:
        # Traduce una etiqueta de opción para mostrarla según self.lang, sin afectar claves internas
        if not isinstance(text, str):
            return text
        # quitar precio al final si viene incrustado para traducir texto base
        base = text
        # aplica traducción sólo visual
        if getattr(self, "lang", LANG_DEFAULT) == "es":
            return _opt_to_es(base)
        else:
            return _opt_to_en(base)
    # === End I18N ===

    @staticmethod
    def _put(mapping: dict, names, value):
        for n in names:
            mapping[f"{{{{{n}}}}}"] = str(value)

    def _pack_generate(self):
        plant = self.var_plant.get(); ruta = os.path.join(_app_dir(), plant)
        if not os.path.exists(ruta):
            messagebox.showerror(APP_TITLE, f"No se encontró la plantilla: {plant}"); return
        base = _parse_decimal_safe(self.var_base.get()); total = base; selected = {}

        # Calcular total y recolectar selección
        for name, info in self.opt_vars.items():
            if info[0] == "chk":
                var, price = info[1], info[2]
                val_bool = bool(var.get())
                if val_bool: total += price
                selected[name.lower()] = "Sí" if val_bool else "No"
            else:
                var, data = info[1], info[2]
                sel = var.get()
                clean = sel.split("($")[0].strip()
                for label, price in data:
                    if label == sel or self._tr_opt(label) == sel:
                        total += price; break
                selected[name.lower()] = clean

        self.var_total.set(f"US${total:,.2f}")

        # Helper: passthrough de porcentaje
        def _pct_passthrough(s: str) -> str:
            t = (s or "").strip()
            if not t:
                return ""  # vacío
            if t.endswith("%"):
                return t  # respeta lo escrito
            # Si es número, agrega %
            tnum = t.replace(" ", "").replace(",", "")
            try:
                float(tnum)
                return f"{t}%"
            except Exception:
                return t  # respeta texto no numérico

        try:
            if not Document: raise RuntimeError("python-docx no instalado")
            doc = Document(ruta)
            data = {}

            # Encabezado y totales
            self._put(data, ["cliente", "nombre del cliente", "nombre_del_cliente"], self.var_cliente.get())
            self._put(data, ["fecha"], self.var_fecha.get())
            self._put(data, ["asesor"], self.var_asesor.get())
            self._put(data, ["disponibilidad"], self.var_disp.get())
            self._put(data, ["validez"], self.var_validez.get())
            self._put(data, ["precio", "total"], f"US${total:,.2f}")
            self._put(data, ["precio_base"], f"US${base:,.2f}")

            # Selecciones comunes
            def sel(*keys):
                for k in keys:
                    v = selected.get(k.lower())
                    if v: return v
                return ""

            self._put(data, ["voltage", "voltaje"], sel("Voltage", "Voltaje"))
            self._put(data, ["lid size", "lid_size", "altura_tapa", "tamano_tapa", "tamaño_tapa"], sel("Lid size"))
            self._put(data, ["pump options", "pump_options", "opcion_bomba", "bomba", "bomba_de_vacio"], sel("Pump Options"))
            vop = sel("Operation", "Operacion")
            self._put(data, ["operation", "operacion"], vop)
            self._put(data, ["corte_mecanico"], ("Con corte mecánico" if "with mechanical cut" in vop.lower() else "Sin corte mecánico"))

            # Gas Flush, Positive Air, Bi-active
            g = None
            for k in list(selected.keys()):
                if "gas flush" in k or "inyeccion de gas" in k or "inyección de gas" in k:
                    g = selected[k]; break
            self._put(data, ["gas_flush", "gas flush", "descarga_gas", "inyeccion_gas", "inyección_gas"], g or "No")

            pa = None
            for k in list(selected.keys()):
                if "positive air sealer" in k:
                    pa = selected[k]; break
            self._put(data, ["positive_air", "positive air", "positive_air_sealer"], pa or "No")

            bi = None
            for k in list(selected.keys()):
                if "bi-active sealing system" in k or "bi active sealing system" in k:
                    bi = selected[k]; break
            self._put(data, ["sellado_biactivo", "bi-active sealing system", "bi_active_sealing_system"], bi or "No")

            # Conceptos y vencimientos: pasar tal cual la fecha y agregar % si el campo es numérico
            for i in range(1, 4):
                raw_pct = self.var_conc_pct[i-1].get()
                pct = _pct_passthrough(raw_pct)
                venc = (self.var_conc_venc[i-1].get() or "").strip()
                self._put(data, [f"concepto{i}", f"concept{i}", f"concept_{i}"], pct)
                self._put(data, [f"vencimiento{i}", f"fecha_vencimiento{i}", f"vence{i}", f"due{i}"], venc)

            # TS placeholders
            self._put(
                data,
                ["photo_registration", "registro_fotografias", "registro_de_fotografias"],
                sel("Registro de fotografías", "Registro de fotograf\u00edas")
            )
            self._put(
                data,
                ["die_configuration", "configuracion_matriz", "configuración_matriz"],
                sel("Configuración de matriz", "Configuración de la matriz")
            )
            self._put(
                data,
                ["die_shape", "forma_matriz"],
                sel("La forma de la matriz (Geometría)", "Forma de la matriz")
            )
            tipo_emp = sel("Proceso", "La forma de la matriz (Proceso)")
            self._put(data, ["tipo_empaque"], tipo_emp)

            
            # Índice (Index) y Sistema de descarga de bandeja (Tray unload system)
            idx_val = None
            for k, v in selected.items():
                if "índice" in k or "indice" in k or "index" in k:
                    idx_val = v; break
            self._put(data, ["index", "índice", "indice"], idx_val or "")

            tray_val = None
            for k, v in selected.items():
                if "descarga de bandeja" in k or "tray unload" in k or "bandeja fácil" in k or "bandeja facil" in k:
                    tray_val = v; break
            self._put(data, ["sistema_descarga_bandeja", "tray_unload_system", "tray unload system", "sistema_de_descarga_de_bandeja"], tray_val or "")

# Reemplazo de placeholders
            docx_replace_placeholders(doc, data)

            # Eliminar filas de la tabla de contrato cuando concepto está vacío o es 0
            try:
                for _tbl in getattr(doc, "tables", []):
                    try:
                        _ncols = len(_tbl.rows[0].cells) if _tbl.rows else 0
                    except Exception:
                        _ncols = 0
                    if _ncols != 2:
                        continue
                    for _r in range(len(_tbl.rows)-1, -1, -1):
                        try:
                            # Primera columna = Concepto (%)
                            raw = "\n".join(p.text for p in _tbl.rows[_r].cells[0].paragraphs).strip()
                            if raw == "":
                                _tbl._tbl.remove(_tbl.rows[_r]._tr); continue
                            num = raw.replace("%","").replace(" ", "").replace(",", ".")
                            try:
                                val = float(num)
                                if val == 0.0:
                                    _tbl._tbl.remove(_tbl.rows[_r]._tr)
                            except Exception:
                                # No numérico: lo dejamos
                                pass
                        except Exception:
                            pass
            except Exception:
                pass

            # Guardado y conversión
            tmp_out = os.path.join(_app_dir(), f"TMP_{uuid.uuid4().hex}.docx")
            doc.save(tmp_out)

            out_docx = filedialog.asksaveasfilename(defaultextension=".docx", filetypes=[("Word","*.docx")],
                                                    initialfile=f"Cotizacion_{self.var_cliente.get()}_{datetime.now().strftime('%Y%m%d_%H%M')}.docx")
            if not out_docx:
                try: os.remove(tmp_out)
                except Exception: pass
                return
            try:
                os.replace(tmp_out, out_docx)
            except Exception:
                shutil.copyfile(tmp_out, out_docx); os.remove(tmp_out)

            out_pdf = out_docx.replace(".docx",".pdf")
            pdf_path = ""
            try:
                if docx2pdf_convert:
                    docx2pdf_convert(out_docx, out_pdf); pdf_path = out_pdf
                else:
                    pdf_path = self._convert_docx_to_pdf(out_docx, out_pdf)
            except Exception:
                pdf_path = ""

            # --- Respaldos automáticos Packaging+ ---
            try:
                backup_dir = os.path.join(_app_dir(), "respaldos")
                os.makedirs(backup_dir, exist_ok=True)
                ts = datetime.now().strftime("%Y%m%d_%H%M%S")

                # Copia DOCX
                try:
                    base_doc = os.path.splitext(os.path.basename(out_docx))[0]
                    b_docx = os.path.join(backup_dir, f"{base_doc}__{ts}.docx")
                    shutil.copy2(out_docx, b_docx)
                except Exception as _e:
                    _write_error_log(_e)

                # Copia PDF si existe
                try:
                    if pdf_path and os.path.exists(pdf_path):
                        base_pdf = os.path.splitext(os.path.basename(pdf_path))[0]
                        b_pdf = os.path.join(backup_dir, f"{base_pdf}__{ts}.pdf")
                        shutil.copy2(pdf_path, b_pdf)
                except Exception as _e:
                    _write_error_log(_e)

                # Respaldo del programa 1 vez por día
                try:
                    import zipfile, glob
                    day_zip = os.path.join(backup_dir, f"program_backup_{datetime.now().strftime('%Y%m%d')}.zip")
                    if not os.path.exists(day_zip):
                        appdir = _app_dir()
                        with zipfile.ZipFile(day_zip, "w", zipfile.ZIP_DEFLATED) as z:
                            for name in [os.path.basename(__file__), CFG_FILE, HIST_PACK, HIST_MATS, ADVISORS_FILE]:
                                p = os.path.join(appdir, name)
                                if os.path.exists(p):
                                    z.write(p, arcname=os.path.basename(p))
                            # Incluir plantillas .docx de referencia
                            for docx in glob.glob(os.path.join(appdir, "*.docx")):
                                try:
                                    z.write(docx, arcname=os.path.basename(docx))
                                except Exception:
                                    pass
                except Exception as _e:
                    _write_error_log(_e)

            except Exception as _e:
                _write_error_log(_e)
            hist = _load_hist(HIST_PACK)
            hist.append({
                "id": str(uuid.uuid4()),
                "fecha": datetime.now().strftime("%Y-%m-%d %H:%M"),
                "cliente": self.var_cliente.get(),
                "plantilla": plant,
                "monto": f"US${total:,.2f}",
                "docx": out_docx,
                "pdf": pdf_path
            })
            _save_hist(HIST_PACK, hist)
            messagebox.showinfo(APP_TITLE, "Documento generado.")
        except Exception as e:
            _write_error_log(e)
            messagebox.showerror(APP_TITLE, f"Error al generar:\n{e}\n\nRevise error.log para más detalles.")


    @staticmethod
    def _convert_docx_to_pdf(input_path: str, output_path: str) -> str:
        try:
            out_dir = os.path.dirname(output_path) or "."
            os.makedirs(out_dir, exist_ok=True)
            subprocess.run([
                "libreoffice", "--headless", "--convert-to", "pdf",
                "--outdir", out_dir, input_path
            ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            gen = os.path.join(out_dir, os.path.splitext(os.path.basename(input_path))[0] + ".pdf")
            if os.path.abspath(gen) != os.path.abspath(output_path):
                try: os.replace(gen, output_path)
                except Exception:
                    shutil.copyfile(gen, output_path); os.remove(gen)
            return output_path if os.path.exists(output_path) else ""
        except Exception:
            return ""

    # ===== Materials =====
    def _build_materials(self, parent):
        head = ttk.LabelFrame(parent, text="Encabezado"); head.pack(fill="x", padx=8, pady=6)
        self._trans_widgets["Encabezado"] = head
        # Materials-specific logo
        try:
            import os
            from tkinter import PhotoImage
            mat_logo_path = os.path.join(_app_dir(), "logo_materials.png")
            if os.path.exists(mat_logo_path):
                img = tk.PhotoImage(file=mat_logo_path)
                # downscale to fit max height 80px
                try:
                    h = img.height(); w = img.width()
                    factor = max(1, int((h/80)+0.999))
                    if factor > 1:
                        img = img.subsample(factor, factor)
                except Exception:
                    pass
                self._logo_materials = img
            else:
                self._logo_materials = self._logo_img
            if self._logo_materials:
                ttk.Label(head, image=self._logo_materials).grid(row=0, column=5, rowspan=2, padx=(12,0), pady=2, sticky="e")
        except Exception:
            pass

        self.var_m_cliente = tk.StringVar(); self.var_m_fecha = tk.StringVar(value=datetime.now().strftime("%d/%m/%Y"))
        self.var_m_asesor = tk.StringVar(value="José Manuel Rayotorres Martínez"); self.var_m_validez = tk.StringVar(value="30 días")
        lbl_mc = ttk.Label(head, text="Cliente:"); lbl_mc.grid(row=0, column=0, padx=4, pady=2, sticky="e"); self._trans_widgets["Cliente:"] = lbl_mc
        ttk.Entry(head, textvariable=self.var_m_cliente, width=38).grid(row=0, column=1, padx=4, pady=2, sticky="w")
        lbl_mf = ttk.Label(head, text="Fecha:"); lbl_mf.grid(row=0, column=2, padx=4, pady=2, sticky="e"); self._trans_widgets["Fecha:"] = lbl_mf
        ttk.Entry(head, textvariable=self.var_m_fecha, width=12).grid(row=0, column=3, padx=4, pady=2, sticky="w")
        lbl_ma = ttk.Label(head, text="Asesor:"); lbl_ma.grid(row=1, column=0, padx=4, pady=2, sticky="e"); self._trans_widgets["Asesor:"] = lbl_ma
        ttk.Entry(head, textvariable=self.var_m_asesor, width=38).grid(row=1, column=1, padx=4, pady=2, sticky="w")
        lbl_mv = ttk.Label(head, text="Validez:"); lbl_mv.grid(row=1, column=2, padx=4, pady=2, sticky="e"); self._trans_widgets["Validez:"] = lbl_mv
        ttk.Entry(head, textvariable=self.var_m_validez, width=12).grid(row=1, column=3, padx=4, pady=2, sticky="w")
        # Selector de plantilla
        from glob import glob
        default_tpl = os.path.join(_app_dir(), "Cotizacion Materials.docx")
        choices = []
        try:
            choices = [p for p in glob(os.path.join(_app_dir(), "*.docx")) if "Cotizacion" in os.path.basename(p)]
        except Exception:
            choices = []
        if default_tpl not in choices:
            choices = [default_tpl] + choices
        self.var_m_tpl = tk.StringVar(value=choices[0] if choices else default_tpl)
        ttk.Label(head, text="Plantilla:").grid(row=2, column=0, padx=4, pady=2, sticky="e")
        tpl_box = ttk.Frame(head); tpl_box.grid(row=2, column=1, columnspan=3, padx=4, pady=2, sticky="we")
        tpl_box.columnconfigure(0, weight=1)
        self.cbo_m_tpl = ttk.Combobox(tpl_box, textvariable=self.var_m_tpl, values=choices, state="readonly")
        self.cbo_m_tpl.grid(row=0, column=0, sticky="we")
        def _browse_tpl():
            path = filedialog.askopenfilename(title="Seleccionar plantilla DOCX", filetypes=[("Word","*.docx")], initialdir=_app_dir())
            if path:
                self.var_m_tpl.set(path)
                vals = list(self.cbo_m_tpl["values"])
                if path not in vals:
                    self.cbo_m_tpl["values"] = vals + [path]
        ttk.Button(tpl_box, text="Buscar plantilla", command=_browse_tpl).grid(row=0, column=1, padx=(6,0))

        # Dynamic items area
        items_box = ttk.LabelFrame(parent, text="Ítems"); self._trans_widgets["Ítems"] = items_box
        items_box.pack(fill="x", padx=8, pady=6)
        self.items_container = ttk.Frame(items_box); self.items_container.pack(fill="x", padx=6, pady=4)
        self.item_rows = []

        hdr = ttk.Frame(items_box); hdr.pack(fill="x", padx=6)
        ttk.Label(hdr, text="Producto", width=60, anchor="w").pack(side="left", padx=(0,6))
        ttk.Label(hdr, text="Cantidad", width=6, anchor="w").pack(side="left", padx=(0,6))
        ttk.Label(hdr, text="Precio unitario", width=14, anchor="w").pack(side="left", padx=(0,6))
        def add_row(desc="", qty="1", each="0"):
            row = ttk.Frame(self.items_container); row.pack(fill="x", pady=2)
            v_desc, v_qty, v_each = tk.StringVar(value=desc), tk.StringVar(value=qty), tk.StringVar(value=each)
            e1 = ttk.Entry(row, textvariable=v_desc, width=60); e1.pack(side="left", padx=(0,6))
            e2 = ttk.Entry(row, textvariable=v_qty, width=6); e2.pack(side="left", padx=(0,6))
            e3 = ttk.Entry(row, textvariable=v_each, width=10); e3.pack(side="left", padx=(0,6))
            bdel = ttk.Button(row, text="–", width=3, command=lambda: remove_row(row))
            bdel.pack(side="left")
            for v in (v_desc, v_qty, v_each):
                v.trace_add("write", lambda *_: self._mat_update_totals())
            self.item_rows.append((row, v_desc, v_qty, v_each))
            self._mat_update_totals()

        def remove_row(roww):
            self.item_rows = [t for t in self.item_rows if t[0] is not roww]
            try: roww.destroy()
            except Exception: pass
            self._mat_update_totals()

        btns = ttk.Frame(items_box); btns.pack(fill="x", padx=6, pady=2)
        btn_addi = ttk.Button(btns, text="Agregar ítem", command=lambda: add_row()); btn_addi.pack(side="left"); self._trans_widgets["Agregar ítem"] = btn_addi
        btn_delli = ttk.Button(btns, text="Eliminar último", command=lambda: (self.item_rows and remove_row(self.item_rows[-1][0]))); btn_delli.pack(side="left", padx=6); self._trans_widgets["Eliminar último"] = btn_delli

        # Opciones
        opts = ttk.LabelFrame(parent, text="Opciones"); opts.pack(fill="x", padx=8, pady=6)
        self._trans_widgets["Opciones"] = opts
        self.var_moneda = tk.StringVar(value="MXN")
        self.var_iva = tk.StringVar(value="16")
        lbl_mon = ttk.Label(opts, text="Moneda"); lbl_mon.grid(row=0, column=0, padx=4, pady=2); self._trans_widgets["Moneda"] = lbl_mon; ttk.Combobox(opts, textvariable=self.var_moneda, values=["USD","MXN"], width=6, state="readonly").grid(row=0, column=1, padx=4, pady=2)
        ttk.Label(opts, text="IVA (%)").grid(row=0, column=2, padx=4, pady=2); cb_iva = ttk.Combobox(opts, textvariable=self.var_iva, values=[str(x) for x in range(0,33,1)], width=5, state="readonly")
        cb_iva.grid(row=0, column=3, padx=4, pady=2); cb_iva.bind("<<ComboboxSelected>>", lambda e: self._mat_update_totals())

        fle = ttk.LabelFrame(parent, text="Flete y notas"); fle.pack(fill="x", padx=8, pady=4)
        self._trans_widgets["Flete y notas"] = fle
        self.var_m_flete_modo = tk.StringVar(value="No aplica"); self.var_m_flete_monto = tk.StringVar(value="0")
        lbl_fle = ttk.Label(fle, text="Flete"); lbl_fle.grid(row=0, column=0, padx=4, pady=2, sticky="w"); self._trans_widgets["Flete"] = lbl_fle
        cb_flete = ttk.Combobox(fle, textvariable=self.var_m_flete_modo, values=["No aplica","Incluido","No incluido"], width=12, state="readonly")
        cb_flete.grid(row=0, column=1, padx=4, pady=2, sticky="w"); cb_flete.bind("<<ComboboxSelected>>", lambda e: self._mat_update_totals())
        lbl_monto = ttk.Label(fle, text="Monto"); lbl_monto.grid(row=0, column=2, padx=4, pady=2, sticky="w"); self._trans_widgets["Monto"] = lbl_monto
        ent_flete = ttk.Entry(fle, textvariable=self.var_m_flete_monto, width=12)
        ent_flete.grid(row=0, column=3, padx=4, pady=2, sticky="w"); ent_flete.bind("<FocusOut>", lambda e: (self._normalize_money(self.var_m_flete_monto), self._mat_update_totals()))
        self.txt_m_notas = tk.Text(fle, width=80, height=2)
        lbl_notas = ttk.Label(fle, text="Notas"); lbl_notas.grid(row=1, column=0, padx=4, pady=2, sticky="nw"); self._trans_widgets["Notas"] = lbl_notas; self.txt_m_notas.grid(row=1, column=1, columnspan=3, padx=4, pady=2, sticky="we")

        bar = ttk.Frame(parent); bar.pack(fill="x", padx=8, pady=(6,2))
        self.lbl_sub = ttk.Label(bar, text="Subtotal: US$0.00", font=("Segoe UI", 10)); self.lbl_sub.pack(side="left", padx=(0,16))
        self.lbl_iva = ttk.Label(bar, text="IVA: US$0.00", font=("Segoe UI", 10)); self.lbl_iva.pack(side="left", padx=(0,16))
        self.lbl_tot = ttk.Label(bar, text="Total: US$0.00", font=("Segoe UI", 10, "bold")); self.lbl_tot.pack(side="left")
        ttk.Button(bar, text="Generar Word/PDF", command=self._mat_generate).pack(side="right")

        # start with one row
        add_row()

    def _normalize_qty(self, var: tk.StringVar):
        try:
            v = int(_parse_decimal_safe(var.get()))
            var.set(str(v if v > 0 else 1))
        except Exception:
            var.set("1")
        self._mat_update_totals()

    def _mat_add(self):
        desc = self.var_desc.get().strip(); qty = _parse_decimal_safe(self.var_qty.get()); each = _parse_decimal_safe(self.var_each.get())
        if not desc or qty <= 0: return
        total = qty * each; [].append((desc, qty, each, total))
        self.tree.insert("", "end", values=(str(qty), desc, _fmt_money(each, self.var_moneda.get()), _fmt_money(total, self.var_moneda.get())))
        self.var_desc.set(""); self.var_qty.set("1"); self.var_each.set("0"); self._mat_update_totals()


    def _tr_opt(self, text: str) -> str:
        lang = self.lang_var.get() if hasattr(self, 'lang_var') else "Español"
        if not text: return text
        # Map common option labels and values
        map_es = {
            "Voltage": "Voltaje",
            "Lid size": "Altura de tapa",
            "Operation": "Operación",
            "Pump Options": "Opciones de bomba",
            "Gas Flush": "Descarga de gas",
            "Positive Air Sealer": "Sellador de aire positivo",
            "Bi-active Sealing System": "Sistema de sellado biactivo",
            "Mechanical Cut w/ Positive Air Sealer": "Corte mecánico con sellador de aire positivo",
            "Index": "Índice",
            "Registro de fotografías": "Registro de fotografías",
            "Proceso": "Proceso",
            "Configuración de matriz": "Configuración de matriz",
            "La forma de la matriz (Geometría)": "La forma de la matriz (Geometría)",
            "Yes": "Sí",
            "No": "No",
            "None": "Ninguno",
            "Automatic lid with NO mechanical cut": "Tapa automática SIN corte mecánico",
            "Automatic lid, WITH mechanical cut": "Tapa automática CON corte mecánico",
        }
        if lang.startswith("English"):
            # If UI in English, ensure English terms
            # Replace Spanish leading keywords
            map_en = {v:k for k,v in map_es.items()}
            for k,v in map_en.items():
                if k in text: text = text.replace(k, v)
            return text
        else:
            # Spanish mode: replace keywords
            for k,v in map_es.items():
                if k in text:
                    text = text.replace(k, v)
            return text

    def _normalize_money(self, var: tk.StringVar):
        try:
            v = _parse_decimal_safe(var.get())
            var.set(f"{v:,.2f}")
        except Exception:
            var.set("0")

    def _mat_update_totals(self):
        subtotal = Decimal("0")
        # sum from dynamic rows
        for (_row, v_desc, v_qty, v_each) in getattr(self, "item_rows", []):
            try:
                q = _parse_decimal_safe(v_qty.get())
                e = _parse_decimal_safe(v_each.get())
                subtotal += q * e
            except Exception:
                continue
        iva_pct = _parse_decimal_safe(self.var_iva.get())
        iva = (subtotal * iva_pct) / Decimal("100")
        total = subtotal + iva
        self._mat_totals = {"subtotal": subtotal, "iva": iva, "total": total, "iva_pct": iva_pct}
        self.lbl_sub.config(text=f"Subtotal: {_fmt_money(subtotal, self.var_moneda.get())}")
        self.lbl_iva.config(text=f"IVA: {_fmt_money(iva, self.var_moneda.get())}")
        self.lbl_tot.config(text=f"Total: {_fmt_money(total, self.var_moneda.get())}")

def main():
    try:
        app = App()
        app.mainloop()
    except Exception as e:
        try:
            with open(os.path.join(_app_dir(), "error.log"), "a", encoding="utf-8") as f:
                f.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {repr(e)}\n")
                f.write(traceback.format_exc() + "\n\n")
        except Exception:
            pass
        try:
            root = tk.Tk(); root.withdraw()
            messagebox.showerror(APP_TITLE, f"Ocurrió un error y la app se cerró.\nRevise 'error.log' en la carpeta del programa.\n\nDetalle: {e}")
        except Exception:
            pass

if __name__ == "__main__":
    main()
